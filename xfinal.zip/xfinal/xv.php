<?php
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_read = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM user ";
    $result = mysqli_query($connection_read, $query);
    if($result){
      echo "<table id='tbl'>
    <tr>
      <th>Sl. No.</th>
      <th>Unique ID</th>
      <th>Name</th>
      <th>Login ID</th>
      <th>Password</th>
      <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['pno'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$row['fname']."</td>";
      echo "<td>".$row['log]."</td>";
      echo "<td>".$row['phn']."</td>";
      echo "<td>".$row['fname']."</td>";
 echo "<td>".ucwords($row['name'])."</td>";
      //echo "<td>".$row['login']."</td>";
      //echo "<td>".$row['password']."</td>";ss
      echo "<td>"."<a href = 'update.php?id=$id' id='update'>EDIT</a>"."</td>";
      echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>DEL</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_read);
require("patientlist.html");


 ?>
