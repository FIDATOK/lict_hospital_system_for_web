<?php
require('session.php');
?>
<?php

//READ DATA FROM DATABASE USING PHP
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_read = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $query = " SELECT doctor.lname,doctor.sex,login_system.name,doctor.dsepc FROM doctor RIGHT JOIN login_system ON login_system.id=doctor.id;" ;
  //  $query = "SELECT * FROM patient " ;
    $result = mysqli_query($connection_read, $query);
    if($result) {
    //  $header=["header"];
      //echo "$header";
      echo "<P>AUTO_UPDATE APPOINMENT FOR FIDATOK FOUNDATION HOSPITAL</P>";
      echo "<table >
    <tr>
      <th>Sl. No.</th>

      <th>Doctor Name</th>
      <th>patient </th>
      <th>Speciallist</th>
      <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
        $id = $row['dsepc'];
      //$id = $row['dno'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$row['lname']."</td>";
      echo "<td>".ucwords($row['name'])."</td>";
      echo "<td>".$row['sex']."</td>";
//echo "<td>"."<script>alert('Your Login Name or Password is invalid');</script>"."</td>";
      //echo "<script>alert('Your Login Name or Password is invalid');</script>";
//echo " "<td>"."<script>alert('Your Login Name or Password is invalid');</script>";"."</td>";
      //echo "<td>".$row['dshow']."</td>";
      echo "<td>"."<a href = 'updateappo.php'>EDIT</a>"."</td>";
        echo "<td>"."<a href = 'updateappo.php'>EDIT</a>"."</td>";
      //echo "<td>"."<a href = 'delete.php?id=$id' id='delete'>DEL</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_read);






require("appo.html");
 ?>
