<!DOCTYPE html>
<html>
<!--//program: hospital managment system
//programmer:MD.Ashikur_rahman(Fidatok)
//Trainer: Suman Gangapadhaya
//Inspired by: Suman Gangapadhaya.
//Enlighten By : Suman Gangapadhaya.
//thanks to :Suman Gangapadhaya.-->
  <head>
    <meta charset="utf-8">
    <title>fidatok.com</title>
    <link rel="stylesheet" href="css/facebook.css">
    <link rel="stylesheet" href="css/well.css">
  </head>
  <body style="height:815px;">

    </div>
    <div class="headerx">

    </div>
    <form  action="#" method="post">
    <div class="header">
      <div id="img1" class="header"><img src= "image/ft3.png"/>

      </div>
<a href="admin.php">ADMIN</a>
      <div id="form1" class="header"> E-mail or User name<br>
        <input type="mail" name="username" value="" placeholder="Email"/>
        <div id="form2" class="header"> password <br>
          <input type="password" name="password" value="" placeholder="password"/><br>
          forgett password</div>
        </div>

        <input type="submit" class="submit1" name="submit" value="submit"/>

        </div>
          </form>


    <!--sing up form -->
    <div class="bodyx">
      <div id="intro1" class="bodyx">OUR PASSION TO KEEP YOU HEALTHY</div>
      <div id="intro2" class="bodyx"> DOCTOR REG: FORM ডাক্তার</div>
      <div id="img2" class="bodyx"><div class="slideshow-container">

      <div class="mySlides fade">
        <div class="numbertext">1 / 3</div>
        <img src="image/doc6.jpg" style="width:100%">
        <div class="text">fidatok {foundation}</div>
      </div>

      <div class="mySlides fade">
        <div class="numbertext">2 / 3</div>
        <img src="image/doc4.jpg" style="width:100%">
        <div class="text">fidatok fund</div>
      </div>

      <div class="mySlides fade">
        <div class="numbertext">3 / 3</div>
        <img src="image/doc5.jpg" style="width:100%">
        <div class="text">fidatok foundation</div>
      </div>

      <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
      <a class="next" onclick="plusSlides(1)">&#10095;</a>

      </div>
      <br>

      <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
      </div>

      <script>
      var slideIndex = 1;
      showSlides(slideIndex);

      function plusSlides(n) {
        showSlides(slideIndex += n);
      }

      function currentSlide(n) {
        showSlides(slideIndex = n);
      }

      function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
      }
      </script>

</div>
      <div id="intro3" class="bodyx"> ITS THE BEST HOSPITAL IN BANGLADESH</div>
<!--sing up input box-->
<form  action="updatedoctor.php" method="POST">


<div id="form3"  class="bodyx">
  <input type="text" id="namebox" name="fname" value="<?php echo $xname; ?>" placeholder="first name" ><br><br>
<input type="text" id="mailbox" name="lname" value="<?php echo $xlname; ?>" placeholder="last name"/><br><br>
<input type="text" id="namebox" name="log" value="<?php echo $xlog; ?>" placeholder="E-mail"/><br><br>

<!-- <input type="password" id="mailbox" name="psw" value="" placeholder="password"/><br><br> -->
<!-- <input type="date" id="namebox" name="date" value="<?php echo $xdate; ?>"/><br><br> -->
<input type="text" id="namebox" name="phn" value="<?php echo $xphn; ?>" placeholder="mobile No.">
<input type="radio" name="sex" value="male"/>male <input type="radio" name="sex" value="female"/>female

<!--By click here <br><br>
<br><hr>
Create a page-->
</div>


    </div>
    <br><br><br>
    <br>


    <input type="submit" class="button2" name="meet" value="singup"/>
  </form>
    <!--div class="body1">
      <div class="body1" id="conclu1"> English <br><hr>
        learn more

      </div>

    </div-->
    <div class="doc">


    <a href="dindex.php">I AM ADOCTOR </a>
    </div>
  </body>
</html>
