<?php
require('session.php');
?>
<?php
//PROGRAM : PHP program to UPDATE a Record in MySQL database for the CRUD App
//CODED BY : SUMAN GANGOPADHYAY
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//DATE : 20-July-2014
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `name`,`user`,`password`,`visible`,`mobile` FROM doctor WHERE `id`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $doctor_name=$row['doctor_name'];
    $gender=$row['gender'];
    $time=$row['time'];
    $date=$row['date'];
    $contact_no=$row['contact_no'];
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('doctor.html');
//Update the data and Save it into the MySQL database;
/*if (isset($_POST['submit'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $docn = $_POST['docn'];
  $gnd = $_POST['gnd'];
  $time = $_POST['time'];
  $date = $_POST['date'];
  $cno= $_POST['cno'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE doctor SET `doctor_name`='{$dname}',
             `gender`='{$gender}',`time`='{$time}',`date`='{$date}',`contact_no`='{$contact}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection_write, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href = 'doctor.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}*/
?>
