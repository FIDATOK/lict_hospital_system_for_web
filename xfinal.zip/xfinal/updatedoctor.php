<?php
require('session.php');
?>
<?php
//PROGRAM : PHP program to UPDATE a Record in MySQL database for the CRUD App
//CODED BY : SUMAN GANGOPADHYAY
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//DATE : 20-July-2014
//modify : by : FIDATOK (asik);
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
 $query = "SELECT `name`, `user`, `password`,  `lname`, `mobile`, `sex`, `dsepc`, `date` FROM doctor WHERE `id`='{$id}'";
 $result = mysqli_query($connection_update,$query);
 if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
   $xname = $row['name'];
   $xdate = $row['dsepc'];
   $xlname = $row['lname'];
   //$psw = $row['psw'];
   $xlog=$row['user'];
   $xphn=$row['mobile'];

 }
}else{
 echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require("updatedoctor1.php");

//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
 $user = 'root';
 $password ='';
 $ip = 'localhost';
 $dbname = 'xfinal';
 $name = $_POST['fname'];
 $sex = $_POST['sex'];
 $lname = $_POST['lname'];
 $psw = $_POST['psw'];
 $log=$_POST['log'];
 $phn=$_POST['phn'];
 $connection_write = mysqli_connect($ip, $user, $password, $dbname);
 if (!mysqli_connect_errno()) {
   $visibility = 1;
   $query="UPDATE  doctor  SET `name`='$name', `user`='$log', `password`='$psw', `visible`='$visibility', `lname`='$lname', `mobile`='$phn', `sex`=$sex, `dsepc`='$dspec', `date`='$date' WHERE `id` ='{$id}' ";
   if(mysqli_query($connection_write, $query)){
     echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
     echo "<script>window.location.href ='doctorlist.php'</script>";
   }else{
     echo "Database Insert Failed";
   }
 }else{
   die("ERROR : ".mysqli_connect_error());
 }
 mysqli_close($connection_write);
}
?>
