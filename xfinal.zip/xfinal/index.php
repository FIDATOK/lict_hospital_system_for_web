<?php
//program: hospital managment system
//programmer:MD.Ashikur_rahman(Fidatok)
//Trainer: Suman Gangapadhaya
//Inspired by: Suman Gangapadhaya.
//Enlighten By : Suman Gangapadhaya.
//thanks to :Suman Gangapadhaya.
session_start();
if(isset($_POST['submit'])) {
  $ip ='localhost';
  $username = 'root';
  $password = '';
  $dbname = 'xfinal';
  $visibility = 1;
  $connection = mysqli_connect($ip, $username, $password, $dbname);
  $myusername = mysqli_real_escape_string($connection,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
  $sql = "SELECT `id` FROM login_system WHERE `user`= '{$myusername}' and `password` = '{$mypassword}' AND `visible` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: home.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}
?>
<?php
require('index.html');
?>
<?php




//require('index.html');

if(isset($_POST['meet'])) {
  $user='root';
  $password='';
  $ip='localhost';
  $dbname='xfinal';
  $name = $_POST["fname"];
  $visibility = 1;
  $sex = $_POST['sex'];
  $lname = $_POST['lname'];
  $psw = $_POST['psw'];

  $string=$_POST['log'];
  $phn=$_POST['phn'];
//$string = "/suman.fgfhjfh@iiht.com/" ;
$regex_rule1="/([a-z0-9_.])+\@+([a-z])+\.+([a-z]{2,6})+\.+([a-z]{2,6})/";
$regex_rule2="/([a-z0-9_.])+(\@)+([a-z])+(\.)+([a-z])/";
$regex_phn="/01[^1-4]\d{8}/";
if (preg_match($regex_rule1,$string) || preg_match($regex_rule2,$string) && preg_match($regex_phn,$phn)) {
  echo "<script>alert('YOUR REG. SUCCESSED!')</script>";
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
//$query="INSERT INTO login_system (`id`,`name`, `user`, `password`, `visible`, `timestamp`, `lname`, `mobile`, `sex`) VALUES ( NULL,'{$name}', '{$string}', '{$psw}', '{$visibility}', CURRENT_TIMESTAMP , '{$lname}','{$phn}','{$sex}')";
$query="INSERT INTO login_system(`id`,`name`, `user`, `password`, `visible`, `timestamp`, `lname`, `mobile`, `sex`) VALUES ( NULL,'$name', '$string', '$psw', '$visibility', CURRENT_TIMESTAMP , '$lname','$phn','$sex')";

mysqli_query($connection_write,$query);
}else{
  echo "<script>alert('MAIL & MOBILE ARE NOT VALIED')</script>";
}
}
 ?>
