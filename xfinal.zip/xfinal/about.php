<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>fidatok.com</title>
<link rel="stylesheet" href="css/about.css">
  </head>
  <header>
    <img id="banner" src="image/banner.jpg" alt="bannner"><br><br>
    welcome to FIDATOK FOUNDATION HOSPITAL
  </header>
  <body>

<p id="Program:">programmer</p>
Name:Md.Ashikur_rahman.<br><br>
Qualification:Diploma In Engineer.<br><br>
profession:Web Developer & Desinger.<br><br>
Email:fidatokr@gmail.com<br><br>
<img id="programmer" src="image/asik.jpg" alt="programmer pic">
<p id="trainer">trainer</p>
<img  id="suman" src="image/suman.jpg" alt="sir pic"><br><br>
Trainer name: Suman Gangapadhaya.<br><br>
profession:LICT_BDJOBS_TRAINER.<br><br>
nationality: INDIAN<br><br>
<p id="institute">INSTITUTE</p>
<img id="lict" src="image/lict.png" alt="lict"><br><br>
I.NAME:LICT_BDJOBS.<br><br>
location:DINAJPUR.<br><br>
<p id="Inspired">Inspired BY</p>
INSPIRED BY:SUMAN Gangapadhaya.<br><br>
profession:LICT_BDJOBS_TRAINER.<br><br>
nationality: INDIAN

  </body>
</html>
