<?php
$ip='localhost';
$username='root';
$password='';
$dbname='xfinal';
$conn=mysqli_connect($ip,$username,$password,$dbname);
 ?>
