<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>fidatok.com</title>
  </head>
  <body>
    <?php
    echo "<script>alert('ITS AN AUTO_UPDATE APPOINMENT SYSTEM #EDIT IS NOT AVAIL#');</script>";
    //echo "ITS AN AUTO_UPDATE APPOINMENT SYSTEM EDIT IS NOT AVAIL";
echo "<script>window.location.href ='appo.php'</script>";
     ?>

  </body>
</html>
