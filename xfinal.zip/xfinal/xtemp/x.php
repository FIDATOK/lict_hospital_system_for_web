<?php
require('session.php');
?>
<?php
//PROGRAM : PHP program to Insert and Read from MySQL database
//CODED BY : SUMAN GANGOPADHYAY
//DATE : 20-July-2014
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//WRITE INTO THE DATABASE
if (isset($_POST['submit'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'php_mysqli';
  $fname = $_POST['fname'];
  $login = $_POST['login'];
  $psw = $_POST['psw'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "INSERT INTO login_system (`name`, `user`, `password`,`visible`)
             VALUES('{$fname}', '{$login}', '{$psw}', '{$visibility}')";
    if(mysqli_query($connection_write, $query)){
      echo "";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
require("adpatient.html");
