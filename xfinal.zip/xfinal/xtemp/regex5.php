<?php
$name= $_POST['fname'];
$email= $_POST['log'];
$psw= $_POST['psw'];
$cpassword=$_POST['cpsw'];

if($name && $email && $psw && $cpassword){
if(preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i",$email)){
  if(strlen($psw)>3){
if($psw==$cpassword){
  mysqli_connect("localhost","root","") or die("we could not connect");
  mysql_select_db("xfinal");
  $username=mysqli_query("SELECT fname FROM user WHERE fname=$name");
  $count=mysql_num_query("SELECT email FROM user WHERE email=$email");
  $checkmail=mysql_num_rows($email);
  if($checkmail !=0){
    echo "this mail already used";
  }else{
    mysql_query("INSERT INTO user(fname,email,psw) VALUES ($name,$email,$password");
    echo "SUCCESS";
  }
}
}else{
  echo "pass not match";
  }
}else{
  echo "pass short";
}
}else{
  echo "valied mail need";

}
require("index.html");
 ?>
