<?php




$ip='localhost';
$username='root';
$password='';
$dbname='xfinal';
$conn=mysqli_connect($ip,$username,$password,$dbname);

//require('funcion.php');

function email_validation($email){
  $regex='/([a-z0-9])+\@+([a-z])+(\.)+([a-z]{2,6})/';
  if(preg_match($regex,$email)){
    return 1;
  }else{
    return 0;
  }
}
//function phone_validation($phone){
  //$regex='/01[^1-4]\d{8}/';
  //if(preg_match($regex,$phone)){
  //  return 1;
  //}else{
  //  return 0;
  //}
//}

/*&& phone_validaton($phone)*/
//require_once('database.php');
if(isset($_POST['meet'])){
  $email=$_POST['log'];
  //$phone=$_POST['PSW']
  if (email_validation($email) == 1){
    $sql="INSERT INTO user(`email`)VALUES('$email')";
    $result = mysqli_query($conn,$sql);
    if($result){
      echo "data success";
    }
  }else{

    echo "<script>alertr('inserty valied mail')</script>";
}
}
require("index.html");
  ?>
