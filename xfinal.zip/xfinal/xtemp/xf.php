<?php
session_start();
if(isset($_POST['submit'])) {
  $ip ='localhost';
  $username = 'root';
  $password = '';
  $dbname = 'xfinal';
  $visibility = 1;
  $connection = mysqli_connect($ip, $username, $password, $dbname);
  $myusername = mysqli_real_escape_string($connection,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
  $sql = "SELECT `sl_no` FROM user WHERE `email`= '{$myusername}' and `psw` = '{$mypassword}' AND `visibility` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: home.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}



if (isset($_POST['meet'])) {
  $user = 'root';
  $password ='';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $psw = $_POST['psw'];
  $email=$_POST['log'];
  $sex=$_POST['sex'];
  $date=$_POST['date'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "INSERT INTO user (`fname`, `lname`, `email`, `psw`, `sex`, `time`, `date`, `visibility`, `sl_no`) VALUES ('$fname', '$lname', '$email', '$psw', '$sex', CURRENT_TIMESTAMP, '$date', '$visibility', NULL)";
    if(mysqli_query($connection_write, $query)){
      echo "";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}





?>
<?php
require('index.html');
?>
<?php

if (isset($_POST['meet'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $psw = $_POST['psw'];
  $email=$_POST['log'];
  $cpassword=$_POST['cpsw'];
  //$sex=$_POST['sex'];
  $date=$_POST['date'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
  //  if($name && $email && $password && $cpassword){
    if(preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i",$email)){
      if(strlen($psw)>3){
    if($psw==$cpassword){
      mysqli_connect("localhost","root","")

    //  $query = "INSERT INTO user (`fname`, `lname`, `email`, `psw`, `sex`, `time`, `date`, `visibility`, `sl_no`) VALUES ('$fname', '$lname', '$email', '$psw', '$sex', CURRENT_TIMESTAMP, '$date', '$visibility', NULL)";
    //  if(mysqli_query($connection_write, $query)){
      //  echo "";

       or die("we could not connect");
    //  mysql_select_db("xfinal");
    //  $username=mysqli_query("SELECT email FROM user WHERE email= $email");
      //$count=mysql_num_query("SELECT email FROM user WHERE email= $email");
      //$checkmail=mysql_num_rows($username);
      //if($checkmail !=0){
      mysql_query("INSERT INTO user(fname,email,psw) VALUES ($name,$email,$password)");
      echo "SUCCESS"
        echo "this mail already used";
      }else{

        echo "SUCCESS";
      }
    }
    }else{
      echo "pass not match";
      }
    }else{
      echo "pass short";
    }
    }else{
      echo "valied mail need";

    }





    ///////
  //  $visibility = 1;
    //$query = "INSERT INTO user (`fname`, `lname`, `email`, `psw`, `sex`, `time`, `date`, `visibility`, `sl_no`) VALUES ('$fname', '$lname', '$email', '$psw', '$sex', CURRENT_TIMESTAMP, '$date', '$visibility', NULL)";
//    if(mysqli_query($connection_write, $query)){
  //    echo "";
    //}else{
      //echo "Database Insert Failed";
    //}
//  }else{
 // die("ERROR : ".mysqli_connect_error());
  //}
  //mysqli_close($connection_write);
//}
 ?>
