<?php
require('index.php')
//PROGRAM : PHP program to Insert and Read from MySQL database
//CODED BY : SUMAN GANGOPADHYAY
//DATE : 20-July-2014
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//WRITE INTO THE DATABASE
if(isset($_POST['meet'])){
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $psw = $_POST['psw'];
  $email=$_post['log'];
  $sex=$_post['sex'];
  $date=$_post['date'];
//



$string=$_POST['mail'];
//$string = "/suman.fgfhjfh@iiht.com/" ;
$regex_rule1="/([a-z0-9_.])+\@+([a-z])+\.+([a-z]{2,6})+\.+([a-z]{2,6})/";
$regex_rule2="/([a-z0-9_.])+(\@)+([a-z])+(\.)+([a-z])/";
if (preg_match($regex_rule1,$string) || preg_match($regex_rule2,$string)){

$connection_write = mysqli_connect($ip, $user, $password, $dbname);
//if (!mysqli_connect_errno()) {
  //$visibility = 1;
///#dubble mail detect


  $query = "INSERT INTO user (`fname`, `lname`, `email`, `psw`, `sex`, `time`, `date`, `visibility`)
  VALUES
  ('$fname', '$lname', '$email', '$psw', '$sex', CURRENT_TIMESTAMP, '$date', '$visibility',)";

  mysqli_query($connection_write, $query);
    echo "";
    echo "email valied";
}else{
echo "invalied mail";
}
}

  ?>
