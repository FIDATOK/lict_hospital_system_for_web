<?php
session_start();
if(isset($_POST['submit'])) {
  $ip ='localhost';
  $username = 'root';
  $password = '';
  $dbname = 'xfinal';
  $visibility = 1;
  $connection = mysqli_connect($ip, $username, $password, $dbname);
  $myusername = mysqli_real_escape_string($connection,$_POST['username']);
  $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
  $sql = "SELECT `sl_no` FROM user WHERE `email`= '{$myusername}' and `psw` = '{$mypassword}' AND `visibility` = '{$visibility}'";
  $result = mysqli_query($connection,$sql);
  $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
  $active = $row['active'];
  $count = mysqli_num_rows($result);
  // If result matched $myusername and $mypassword, table row must be 1 row
  if($count == 1) {
    $_SESSION['login_user'] = $myusername;
    header("location: home.php");
  }else {
    echo "<script>alert('Your Login Name or Password is invalid');</script>";
  }
}



if (isset($_POST['meet'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $psw = $_POST['psw'];
  $email=$_POST['log'];
  $sex= $_POST['sex'];
  $date=$_POST['date'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "INSERT INTO user (`fname`, `lname`, `email`, `psw`, `sex`, `time`, `date`, `visibility`, `sl_no`) VALUES ('$fname', '$lname', '$email', '$psw', '$sex', CURRENT_TIMESTAMP, '$date', '$visibility', NULL)";
    if(mysqli_query($connection_write, $query)){
      echo "";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}



//regex
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $nameErr = "Name is required";
  } else {
    $name = $_POST["fname"];
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }

  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = $_POST["email"];
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["website"])) {
    $website = "";
  } else {
    $website = ($_POST["website"]);
    // check if URL address syntax is valid
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$website)) {
      $websiteErr = "Invalid URL";
    }
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = ($_POST["comment"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = ($_POST["gender"]);
  }
}

function ($data) {
$data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
return $data;
}
?>
<?php
require('index.html');
?>
