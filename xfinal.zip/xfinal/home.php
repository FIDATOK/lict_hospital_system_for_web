<?php
require('session.php');
?>
<?php
//PROGRAM : PHP program to Insert and Read from MySQL database
//CODED BY : SUMAN GANGOPADHYAY
//reform & modified by : Fidatok (asikur)
//DATE : 20-July-2014
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//WRITE INTO THE DATABASE

require("home.html");
?>
