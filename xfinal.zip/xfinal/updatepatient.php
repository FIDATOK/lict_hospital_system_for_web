 <?php
//PROGRAM : PHP program to UPDATE a Record in MySQL database for the CRUD App
//CODED BY : SUMAN GANGOPADHYAY
//DATABASE NAME : php_mysqli
//Table Name : userinfo
//DATE : 20-July-2014
//modify : by : FIDATOK (asik);
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT `date`,`occu`,`phn`,`adr`, `spec`,`fname` FROM patient WHERE `sl_no`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $xdate=$row['date'];
$xoccu=$row['occu'];
$xphn=$row['phn'];
$xaddr=$row['adr'];
$xfname=$row['fname'];

  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('patientupdate.html');
//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
  $user = 'root';
  $password ='';
  $ip = 'localhost';
  $dbname = 'xfinal';
  $date=$_POST['date'];
$occu=$_POST['occu'];
$phn=$_POST['phn'];
$addr=$_POST['addr'];
$fname=$_POST['fname'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query="UPDATE  `patient`  SET `date`='{$date}',`occu`='{$occu}',`phn`='{$phn}',`adr`='{$adr}',`spec`='{$spec}',`fname`='{$fname}' WHERE `sl_no` ='{$id}' ";
    if(mysqli_query($connection_write, $query)){
      echo "<b><script>alert('SUCCESS : Data update successfully');</script></b>";
      echo "<script>window.location.href ='patientlist.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
?>
