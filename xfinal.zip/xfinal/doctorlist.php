<?php
require('session.php');
?>
<?php
require("doctorlist.html");
//code Giver= SUMAN GANGOPADHYAY
//modified by asikur rahman

//READ DATA FROM DATABASE USING PHP
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'xfinal';
$connection_read = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $query = "SELECT * FROM doctor WHERE `visible` = 1";
    $result = mysqli_query($connection_read, $query);
    if($result){
      echo "<P>DOCTOR LIST OF FIDATOK FOUNDATION</P>";
      echo "<table id='tbl'>
    <tr>
      <th>Sl. No.</th>
      <th>DOCTOR NAME</th>
      <th>EMAIL</th>
      <th>Mobile</th>
      <th>Specialist</th>
      <th>Update Record</th>
      <th>Delete Record</th>
    </tr>";
    $sl_no = 0;
    while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
      $sl_no = $sl_no + 1;
      $id = $row['id'];
      echo "<tr>";
      echo "<td>".$sl_no."</td>";
      echo "<td>".$row['name']."</td>";
      echo "<td>".ucwords($row['user'])."</td>";
      echo "<td>".$row['mobile']."</td>";
      echo "<td>".$row['dsepc']."</td>";
      echo "<td>"."<a href = 'updatedoctorx.php?id=$id' id='update'>EDIT</a>"."</td>";
      echo "<td>"."<a href = 'deletedoctor.php?id=$id' id='delete'>DEL</a>"."</td>";
      echo "</tr>";
  }
  echo "</table>";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_read);
?>
