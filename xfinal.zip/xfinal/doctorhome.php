<?php
require('session.php');
?>
<?php
require('doctorhome.html');

 ?>
