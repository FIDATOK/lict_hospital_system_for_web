<?php
function email_validation($email){
  $regex='/([a-z0-9])+\@+([a-z])+(\.)+([a-z]{2,6})/';
  if(preg_match($regex,$email)){
    return 1;
  }else{
    return 0;
  }
}
function phone_validation($phone){
  $regex='/01[^1-4]\d{8}/';
  if(preg_match($regex,$phone)){
    return 1;
  }else{
    return 0;
  }
}

 ?>
