<?php
echo "<script>alert('YOU ARE NOT ELIGIBLE FOR THIS  FEATURE,<br> PLEASE REGISTER FIRST');</script>";
  echo "<b><script>alert('নিবন্ধন ব্যতীত প্রবেশ অধিকার বাঁধা প্রাপ্ত');</script> </b>";
require('alert.html');
 ?>
